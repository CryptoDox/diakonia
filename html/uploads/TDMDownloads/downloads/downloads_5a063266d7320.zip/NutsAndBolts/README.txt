Version: 0.3.1


Français

- allez dans le menu "Customize", puis "Customize User Interface..."; Choisissez l'onglet "Toolbars"; Dans "Category", sélectionnez "ElDuke3D"; Puis choisissez un des 2 scripts (Français ou Anglais), et cliquez et déposez le où vous le souhaitez dans la barre d'outils. Vous pouvez mettre les 2 scripts si vous le voulez.

N'oubliez pas de me soutenir: https://elduke3d.shost.ca/modules/AMS/article.php?storyid=1

English

- Go in "Customize", then "Customize User Interface..."; choose "Toolbars"; In "Category", choose "ElDuke3D"; Else choose one of the 2 scripts (French or English), and drag and drop where you want the buton in the bar menu. You can use the 2 scripts if you want.

Don't forget to support me: https://elduke3d.shost.ca/modules/AMS/article.php?storyid=1

Changelog


Français

- Fonctionne sous 3DS Max 2017

- Installation facile grace au fichier "MZP"

- Interface en Français ou en Anglais au choix

- Aide en Français et en Anglais

- Aide en ligne: https://elduke3d.shost.ca/modules/AMS/article.php?storyid=4


English

- Work find with 3DSMax 2017.

- Easy install with MZP.

- French or English language available for interface

- French or English language available for help

- Help online: https://elduke3d.shost.ca/modules/AMS/article.php?storyid=3