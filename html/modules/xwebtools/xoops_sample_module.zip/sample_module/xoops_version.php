<?php
// ------------------------------------------------------------------------- //
//               Xoops: Content Management System                           //
//                       < http://www.xoops.org >                          //
// ---------------------------------------------------------------------- //
// Module: sample_module												 //
// Author: Jan304														//
// Author Email : jan304@pandora.be 								   //
// Author website: http://www.jan304.org							  //
// ----------------------------------------------------------------- //

$modversion['name'] = "Sample module"; // name of module
$modversion['version'] = 1.0; // version
$modversion['description'] = "Here belongs a description"; // a description
$modversion['credits'] = "Jan304 - The XOOPS Project"; // credits
$modversion['license'] = "GPL see LICENSE";
$modversion['official'] = 0;
$modversion['image'] = "logo.gif"; // logo (shown in admin)
$modversion['dirname'] = "sample_module"; // dir name, must be correct in order to avoid conflicts
$modversion['author'] = 'Jan304 - http://www.jan304.org'; // name of author, maybe including url, like here :)

// Menu
$modversion['hasMain'] = 1; // has it main? ofcourse :)

// Admin things
$modversion['hasAdmin'] = 0; // has it admin, NO :)

// Templates
$modversion['templates'][1]['file'] = "sample_index.html"; // template file, must exist in templates dir
$modversion['templates'][1]['description'] = "The template file of the index sample file"; // description of template
$modversion['templates'][2]['file'] = "sample_secondfile.html";
$modversion['templates'][2]['description'] = "Your second template, here clear description of it";
/*
$modversion['templates'][3]['file'] = "sample_thirdfile.html";
$modversion['templates'][3]['description'] = "Your third template, here clear description of it";
*/

?>
